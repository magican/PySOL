from PyQt4.QtNetwork import *
