from PyQt4.QtSvg import *
