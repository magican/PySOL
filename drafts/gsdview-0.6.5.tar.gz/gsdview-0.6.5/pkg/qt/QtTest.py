from PyQt4.QtTest import *
