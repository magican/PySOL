#hiddenimports = ['numpy.core.multiarray',]
#~ hiddenimports = ['PyQt4.QtSvg',
                 #~ 'uuid',            # needed by enthought
                 #~ 'shelve',          # needed by enthought
                 #~ 'cgi',             # needed by enthought
                 #~ ]
hiddenimports = ['gsdview.gdalbackend', 'gsdtools.ras2vec', 'gsdtools.stats']
