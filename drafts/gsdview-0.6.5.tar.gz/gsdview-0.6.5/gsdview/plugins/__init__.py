# -*- coding: utf-8 -*-

# @NOTE: packaging is easier if gsdview.plugins is a python package.
